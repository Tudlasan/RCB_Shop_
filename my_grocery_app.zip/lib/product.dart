import 'package:flutter/material.dart';

class Product {
  final String id;
  final String name;
  final String vendor;
  final double price;
  final String imageUrl;

  Product({
    required this.id,
    required this.name,
    required this.vendor,
    required this.price,
    required this.imageUrl,
  });
}

// 🏍️ RCB Motor Parts Product List
final List<Product> productList = [
  Product(
    id: '1',
    name: 'RCB Brake Master Cylinder S1',
    vendor: 'RCB Official',
    price: 2850.00,
    imageUrl:
        'https://www.racingboy.com.ph/wp-content/uploads/2019/01/S1-Masterbrakepump_L-gold-1024x667-461x300.jpg',
  ),
  Product(
    id: '2',
    name: 'RCB Clutch Lever (Adjustable)',
    vendor: 'Racing Boy',
    price: 1650.00,
    imageUrl:
        'https://www.racingboy.com.ph/wp-content/uploads/2022/03/S3-Brake-Lever-Black-2-1024x1024-400x400.png',
  ),
  Product(
    id: '3',
    name: 'RCB SP522 Shock Absorber',
    vendor: 'RCB Performance',
    price: 5200.00,
    imageUrl:
        'https://5.imimg.com/data5/ECOM/Default/2024/2/390093854/TE/XC/VZ/68809022/rcb-shock-absorber-for-aerox-305mm-sb2-series-moto-modz-2-500x500.jpg',
  ),
  Product(
    id: '4',
    name: 'RCB Alloy Wheel Set 17"',
    vendor: 'RCB Racing',
    price: 10500.00,
    imageUrl:
        'https://lrlmotors.com/cdn/shop/products/royal-enfield-himalayan-rear-alloy-rim-17-x-215-racing-boy-952949.jpg?v=1623610908',
  ),
  Product(
    id: '5',
    name: 'RCB Racing Chain 428H Gold',
    vendor: 'Racing Boy',
    price: 950.00,
    imageUrl:
        'https://lrlmotors.com/cdn/shop/products/rcb-chain-428hs-hd-series-gl-132l-889850.png?v=1656018665',
  ),
  Product(
    id: '6',
    name: 'RCB Handlebar Clip-On',
    vendor: 'RCB Motorsport',
    price: 2400.00,
    imageUrl: 'https://cdn.store-assets.com/s/748078/i/88007678.png?width=480',
  ),
  Product(
    id: '7',
    name: 'RCB S2 Brake Caliper',
    vendor: 'RCB Performance',
    price: 3100.00,
    imageUrl:
        'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSn87WRvPGteecL8YPCtNkE_To0AN7mGyDajQ&',
  ),
  Product(
    id: '8',
    name: 'RCB Fuel Cap CNC Billet',
    vendor: 'RCB Accessories',
    price: 890.00,
    imageUrl:
        'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR0thPATnn5vyTe3b_rJLcvqzpy1jcOkkKapw&',
  ),
  Product(
    id: '9',
    name: 'RCB S1 Foot Peg Set',
    vendor: 'Racing Boy',
    price: 1450.00,
    imageUrl: 'https://cdn.store-assets.com/s/748078/i/83400306.png?width=480',
  ),
  Product(
    id: '10',
    name: 'RCB Reservoir Tank (Universal)',
    vendor: 'RCB',
    price: 799.00,
    imageUrl:
        'https://roadkidzmotorparts.com/cdn/shop/files/5ac36eecae7d48bd828366cd08b2fdad_tplv-o3syd03w52-origin-jpeg_1024x1024.jpg?v=1721387297',
  ),
];
