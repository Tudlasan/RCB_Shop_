import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:my_grocery_app/app_drawer.dart';
import 'package:my_grocery_app/shop.dart';
import 'package:my_grocery_app/newsstand.dart';
import 'package:my_grocery_app/info.dart';
import 'package:my_grocery_app/cart.dart';
import 'package:my_grocery_app/provider.dart';
import 'package:my_grocery_app/profile.dart';

void main() {
  runApp(
    ChangeNotifierProvider(
      create: (context) => CartProvider(),
      child: const MyApp(),
    ),
  );
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'My Grocery App',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.green),
        useMaterial3: true,
      ),
      home: const MyHomePage(),
      routes: {
        '/shop': (context) => const Shop(),
        '/newsstand': (context) => const Newsstand(),
        '/info': (context) => const Info(),
        '/cart': (context) => const Cart(),
        '/profile': (context) => const MyProfilePage(),
      },
    );
  }
}

class MyHomePage extends StatelessWidget {
  const MyHomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('My Grocery'),
        backgroundColor: Colors.white,
        foregroundColor: Colors.black,
        elevation: 1,
      ),
      drawer: const AppDrawer(),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Text(
              'Welcome to RCB Shop App!',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 20),
            ClipRRect(
              borderRadius: BorderRadius.circular(12),
              child: Image.network(
                // ✅ Dashboard image under welcome message
                'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRH5y9hXgPVyP95P7f5PRxEqk3hiRkd_MVAr0iutpYCp4QDqLWThCJGh-BL_nkkAB76fBw&usqp=CAU',
                height: 250,
                width: 500,
                fit: BoxFit.cover,
              ),
            ),
            const SizedBox(height: 20),
            const Text(
              '• Affordable • Quality',
              style: TextStyle(
                fontSize: 16,
                color: Colors.green,
                fontWeight: FontWeight.w500,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
