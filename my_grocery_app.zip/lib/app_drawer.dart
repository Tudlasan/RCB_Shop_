import 'package:flutter/material.dart';

class AppDrawer extends StatelessWidget {
  const AppDrawer({super.key});

  @override
  Widget build(BuildContext context) {
    final List<String> news = [
      'Top Stories',
      'World',
      'Business',
      'Technology',
      'Entertainment',
      'Sports',
      'Science',
      'Health',
    ];

    return Drawer(
      child: ListView(
        children: [
          // 👇 Drawer Header with full image
          DrawerHeader(
            decoration: BoxDecoration(
              image: DecorationImage(
                image: NetworkImage(
                  'https://cdn.brandfetch.io/rcb.com/fallback/lettermark/theme/dark/h/256/w/256/icon?c=1bfwsmEH20zzEfSNTed',
                ),
                fit: BoxFit.cover, // 👈 makes it fill the entire header area
              ),
            ),
            child: Container(
              alignment: Alignment.bottomLeft,
              child: const Text(
                'Rcb Shop App',
                style: TextStyle(
                  color: Color(0xfff8f5f5),
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                  shadows: [
                    Shadow(
                      offset: Offset(1, 1),
                      blurRadius: 4,
                      color: Colors.black54,
                    ),
                  ],
                ),
              ),
            ),
          ),

          // 👇 Drawer menu items
          ListTile(
            leading: const Icon(Icons.store),
            title: const Text('Shop'),
            onTap: () => Navigator.pushNamed(context, '/shop'),
          ),
          ListTile(
            leading: const Icon(Icons.newspaper),
            title: const Text('Newsstand'),
            onTap: () {
              Navigator.pushNamed(context, '/newsstand',
                  arguments: {'news': news});
            },
          ),
          ListTile(
            leading: const Icon(Icons.info_outline),
            title: const Text('Who We Are'),
            onTap: () => Navigator.pushNamed(context, '/info'),
          ),
          ListTile(
            leading: const Icon(Icons.person_outline),
            title: const Text('My Profile'),
            onTap: () => Navigator.pushNamed(context, '/profile'),
          ),
          ListTile(
            leading: const Icon(Icons.shopping_cart),
            title: const Text('Basket'),
            onTap: () => Navigator.pushNamed(context, '/cart'),
          ),
        ],
      ),
    );
  }
}
