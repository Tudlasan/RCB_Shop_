import 'package:flutter/material.dart';

class MyProfilePage extends StatelessWidget {
  const MyProfilePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        title: const Text('My Profile', style: TextStyle(color: Colors.black)),
        backgroundColor: Colors.white,
        iconTheme: const IconThemeData(color: Colors.black),
        elevation: 0,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            const SizedBox(height: 20),
            const CircleAvatar(
              radius: 60,
              backgroundImage: NetworkImage(
                // ✅ Your real profile image here
                'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAJQAAACUCAMAAABC4vDmAAABIFBMVEXL4v////8AAAC+2PtKgKr/3c7vyYRAcJM2Xn3qvGvigIb/y77N5P8TFRjD2vTR6f//1Mb53c+/oWo9NDHwwW4nJyfD3v/1z4i1tbX/5NXR0dE6OjrywbVYRkHq6ur09PTHx8eFhYW8l1bb29vV7v8aGhqNjY1YWFgjPVEMFRx3d3ehoaGpjl0xVXAIDhMMDAxmZmZISEgpR16dr8ImKi+XekURHihseoyaglXs0sQWJjORUlbNdHobLz4yNz+KmqpXYm9ETlu1yt+uxeRjbn17ipu0nJEpFxhQLS+vY2g8QkwwJxddTDCLdE0dGBDTsXTHr6NOQStrVU+Oe3PPp197YzhyY1w/JCZsPUBpVTDnz6Q+NCGxjITSqp51Y0EwJSIpTzPCAAAQBElEQVR4nMWcC1caO9fHp4MKtCN4QUE8igqKlsIgqFQt5W6ttd6PrU9P6/f/Fu9k5zJJJskM2PbNOussKnP5sfc/Ozt7krFevaQVivmNys7b8uqS69q26y6tlt/uVDbyxfUXXdaa+Mz13E59f8lWtqX9+k5ucrDJoIq5t2oasb3NFQt/CapYKWsMpDBZuVL881DFyqp424+9bqs16jRR64xGrVa391E8YnVsrvGg8nXeRgfdTrOfSjlp0hzHWV5ejsUGg+aoe8Dbq57/U1DrOc5IvVEzlS4hDsfimmN5UF5bdpY9sh7HVRlD95GhCr7f3J5nIM8wlqZhrphntEGn6/pejCz6iFCFyja9eLfTRxbSEXHmAot5XPTM2ahY0aCY4w5afUdvoqC1EFds0KICW839NqiNMrnmRSdVMtpIaa1YzIqNLsglylEkHw5V2KFInrSjEQWs5ZmrSbDcnXAfhkJtrFIrGaStsRZH5cm+Q+LX6sYLoQqbREudMa0UNJZnrRHR1maIscxQRaKm4WRISFoxHmswJMoyx3gjVI6MJM0JkQLGii03iQ+N3dAERVzXSqUjmESO7f43IlWMGGtzIqj1ekQzOQ7qAimvwSfF0THRWFhZdf24o4Uq7OMxrm82k5MuOf3OaNjt9nrd4XDU6Tul4K8QjTXA0WFfK3cdVB5HgpbRTF5w73e4URc3b2QMRH2BKma1cGzQBVINVBGnKB0Tk+erZndPRkJtr9uUg5pItdyB45Y0nVANtQHD72zT5Lp0qqMkIoGtKXUPyVZNuMO2Oo4qoYo4JRgYmJwSHTdQ+3L59b3Xvl5+8f920S8JxpJsNYCDtpW2UkHlwXcXpkiQ7tOE5Ory6/VMlrWZ66+XV+SroXQFiQoi1pJKVwqoAmh81sRUojHQBqIZrnn/WqD2umiWTLYCf6wq+mAQan0f20kvccfBOrV/vBOBCNa178SOGLYEqhi21X4wXgWhcMw02MkptaiVFEge1AJKgZ/wMSNBWEpd1cOhYGyZNWmcRJlbNZIH9d771s08/IDDWo6JCjy4GQaFx2BTLHD6MExczmiYZrK/0NfJTPKJ2Io/W6JqwiHy6CxBFUOZPKgT5DodkteQ9w6TyWTmX6wr4WqirCyszqIJqlDGFjcweVRefvxej5RdQNfYynhUSaByBwaqZdBCuWCAAkH1QtKComckg52yyGtfktCIrVKGLmhdBGUlQG2g7z/2Qwyl5wGmaxQ7vzxgKqyroSG0xwYg0Q0dVGEpVFAe0/9CoL7avvs8tX8JXlNyYDMQQ3komEu1jCJ3rGKYoXB8eiKWymwh2R+kDQ5chlx0Rw2FnWeI5F7H63YXQqAuSSx/yBCqw2APlBwYQ5HdzSuhyqERKuWd/ePayPSODjD/ZqitFL9V5cCyCgrC5tCYQUFQMUFh5z0vev+7Ek3VNJkKOzAXhILc4MDkPCuNzHxrZLpFVz+7EUyVRH+8MGQxpAf6WmdQlaDrZe/10SHv9SEqOwNMayvTd0FV9U1hwRqhQyoyVGHWNucrnqHgTJOdQOSLx9MrYKpbaqkkDIGm7BhrfbsgQUUwVAolm5daQ2WvcVpwszI9Pf2IPh1SUyHYrvSDJVV1eFMRqPVV8LtxPgXee6fLV7LvIAt2gWnun20+gm4F/RfQOhptVtcFqEp4LHdQx73S9L3s9S/bt9P03Jv/eAc+IN6m9ItVYSEnQK2GKgpLStn3stnr9xhpETN5UHOg9cuM3/8kUTmSqGJgKh4qH6oob7KAJPWkIMpefyVJ+eIxZvKg3vzzzMkKDcvdkng92X/QjfIcFMrLD0KqmSXUQVhuh+dTMzPXC5TIdu/np6cZ1JufNqOCDOajBCXHqhiKVXUfCibpLfkksTnWgR+lstmFX157urylczwvPBHXUag5kBVEK4hUB5axvoALDHgibzGZmxXlRQQUyRYwFBvhWLvjkDDUG1/s0P1mAzeQwzqLChaVeTfEexxU9r2M9HgzzzMRqDdI7O7l09PhoQoqIPUulTqCKkaQOQeFk3Dattcez0QiHwqLnbSgpWSpQwAtEijkPTckCeYtBaPJ893j3eP92c3x8YqM5EOtGaEC/nOJ/yySSMkdVg+FDXW/QloAKDqUI5nKQfW3MoaCvheSmfNQSOXPx0oYFdTa/ZrOUir/of5nkewuzHsS1Np8ZKizlZWzbTWUsv/lAAo9o+6FBIQXQU2v3KuhZP/FkP/eAhTCG4WWyl8EdaOxlHKoQVDrdhRJvQzqLCIUpArrHhRIKtR7L9LU/JoGSiMqC6agB+EPOiaHmj9e0/S+ANQyGl93PKh6lCj1AihD8AxGKjTS1F9ZUOIMG2P+FhQofb9g4dAZ/ujsj0AFJjVNCJ9WPlLofAmUe/XlVgelVHreQmUNY1VDDRV9mDnc2kpuRYZC6e2GVYkUzwMDciQoyIi3MhlNkqeAgphesVBE6EZ4GuunLlCquzFCvfGhrh60mSdqsqhQ99ux0MhnLJQFodBM+F6dswhQc2jIM6TDCiioy761ymNDQZK3aIIi3ptDJaGn8aHq1mqk4VhIh2HacGygIt77BwrqmbGgUKBatZaixU5hNmOH+I9AIe/ZyfEshaCWLDdSjiDOZpD/DLknP22AifsYUCj53J4IasFoqjlO5rjwMgYUCumuZY8PRUrANxoqLh7Yl8kx3QcZ1WRQYKpFs8oXmaHGh5rAfR4VPHNRDoDCsPdvZlxLdcB940GxQh6UEh+1TDBjZ09oMsppuwEqakjApaBfWVq5g3RkTY5Wc7zvXFYfVpaClFA4JEQNnrhodslqZbjw8iyqnfS7n7iGsMUq6VCJjQy1GnmYsdJizZM+8Li78afupNvd2RLTg14jqmGmHHlAtpx+zeYf02YXcMFs++5mHooKc1Aq+3mHl39c+UzgvZo6kVQPyDh1ibSSDJ6g+A9FyUMPUPzZ2c3Pnz//+++R/uX2wWd6QH8Yqq+pTl2iJnnEf3wpViyebW/z/zpkTOTpqKaHS0wkyYuaDnutBEulOAcGKnoqKPwcuaeZxElMJB2OOnGwkKpgdTKLVQC1eL8o4uA/MCj8uEhbk5Oh0MH5yFMs1PADPy9YZTmolembs0cyl1p7PLuZXuGgMknV2gS/aaZYUSejYKo0Xnp4u5BlBdnF+Wmv580fQ8OffajMFu4LQ91TH+VkdD3ytB1TOWRB5C+00IVCSY1BZR6wmeyhrnfrpu1RCxzUVmRF0NXXmawZKpM8JJV/w2pDyXuswBGxFMSomkTQP97NmKCShz/IgU1DFJQjAjo+F71oxlo61SJbBK5cPdQVsZLbMi071hbNIpYXOWOVmtzaTg0Uab1myeQDbXkRCrHyw9QQrHTzIArUQcgSX0MhNmcKbsqWdjrRoEaO2QOq0Jkbo7jP/T6H2qmmh6pRW5nGekNxvxDpMQhrpRSJCvburh4KvoN4kNJeWRml0Pou+sCoFk1UTpoup7RPqgkTVKJ6Qg7saDe1yN7jHxjlIwQFx3HSpVJp0KQrYRuJhBkqkWiQQ7vNgXdqOrCK3vhoLewhJFr7nur3my1/tTC6J4Z6DkI9CwcQcbWafdgr5d/F/BDS+LgWrYIfdIY9fhfaUTVhgrpiUInqEXfaQW/YGXBr6FV9rxLhwbaTTjGH+a2B74j9E4QKHCK0Lt0TFPJgW7sEIO2MLgJX9VqVh5Kmfis8VFV19kccvmTvSUsA8Mq3QFLFB27ktHajGp/a5aiqqLs83vCPR1dWbtDkwa1yTLtT8WqjLTjSC/VKmW/wy0qQ/3qSqRxnxK5y0kjEp3Bro3/vVRkUwppeQTjovzM8n8FQVVja3yYnxhONE3bBkXJZyVLYAhwnTcR0UqU8uMGV9+CmNXqPu/szr93f0X/XAAqYToST4zR8dVWriCuqpUqCnXCSuZeYkhtcts3uqmrA3A4yoUbOGopQiqVKeI0nr6oSZmoErum1I3rbIzWSpz+KfKQ6H3fJISd15aKuwPI3kmBWVdcEKHAQstn56SfXp3E/nZ4j+1DnKqGmcAdoch5E871ZefmbtP4NlnTadtB1SBZgnxPqoPPXrz+cnp5/89r599MPr1+fU+eCm4/iqmsA1cGAGUq9UFBaUol3DCh9F8d2adCQ/u211L7ZJKBjL7kqqjhElhZ1oG5JpbD41LHUGkUNfr/bYNHz0weR6cMnipxouLrLxLG5qaF0i0+FZbp4Kqx0XgJ9U+MD9mcR6jNokYT8mvo68XgcrjNa9sOBcpkut6DZSfW0hkLG2SP3TCRqQahTBE2/h/AZUEEcNWSqnq9yfkU6v/Qb1u2jAhpePak0FEj0iN4TtPxdhPpOe0GCBo1AFwYodCF3wJynWfrtL5KHeFBTdhvsPmapdlDp32jnY/6Vfx0wxcHKXlQIWSSPHXjQx7t12kqmqfgef1PoRCKUbbNsCn+/F1cxxeMnuP+FbCegGy9KUAjeVUNBmsA0A71e6H4fWLygmpMvRKHQhXrOctjGC7pFBUrmyiCFrimYIqB0QedgSI2hAOpjOnyLCt3MY4Kasnmp78lKRzrf4/uBrWHCUHg0M27moduetk1QCd5UZKDxGxtk6LeizOMiFC7ehmx7YpuPDVB4POYcxMd0iOfMudWAoiQoOygoFRTZSmeC4k0lx3Q+nntNPjWugIqwlY5sOjRBTdW4O6PPpxqdJ+RQF1dARdp0SLZnmqDinNYlUQmSUkdNESra9ky6kVWdCOHW9oORFD6FeGFkwmlr1I2sbMuvgQp9jScHoqg4STV2dQEKM+FuHnnLrzfegK3k8YFrgHISFJUvqZPAPEZkAl2OszmabSNXJwrMgbs0QJ7zkjpRxnKRCSfp420jZxvutWqPMwfykYpFKTxN1SFRjY+54Z69muBE58Iq7YG8qJikQMRVDRMefSZ4NQF7icORzoXMgQjguz/wHVHntTVMeDI/0UscXrERR+fCGokLiO4ThvqEoxQkNDUNE4mZm4YbR3kxiCZiQaf20nU/pyK5FDZFQolEq2gTvxjEf4WKOuFrkLhg06CAAoJLBNVQMhEzveQVKv7LZvaU83ciqyMaFM5BUm1OUCJSgxREXvaymVcsNngWCULhyXKDTknxNBTsR6bFSs+9+LU8yFg7rhYLjxUNEtQhnOO5ekKLZP+OFxghY9FXPbUDWICwt4f9d04/g6BEx9EaXjnUTBGhvLGQ5Fj2XkPqiW2bNpwh2FRQfLDcpcW13/hSrFfo9WHstW+7YurG6mafP9NPR0L4rjLu3/z6sFfii9Z4N8Zp3fP7d/KhluCU1P6DL1oDrBx1IvJQlYIlKCq9fZUCNXzf/qFX0kHL1/n3CR7teventULWdpHLGrt8OXSpHkXek0KhN/jtiwxH7V3xD+0TqTz7p19ziLkqZen9i/r2d14IiVtxY9MNJ/qbr84krbCxU9eZ7P/lJaMMbD2/kdvZrO8vbbu2O7vtwbzdyW3kJzMQa/8HE4KQJ5gm6mwAAAAASUVORK5CYII=',
              ),
            ),
            const SizedBox(height: 15),
            const Text(
              'Aina Cabonce Tudlasan',
              style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
            ),
            const Text(
              'ainacabonce123@gmail.com',
              style: TextStyle(color: Colors.grey),
            ),
            const SizedBox(height: 30),
            ListTile(
              leading:
                  const Icon(Icons.location_on_outlined, color: Colors.green),
              title: const Text('Address'),
              subtitle: const Text('Cabadbaran City, Philippines'),
            ),
            ListTile(
              leading: const Icon(Icons.phone_outlined, color: Colors.green),
              title: const Text('Phone'),
              subtitle: const Text('+63 938 386 5472'),
            ),
            const SizedBox(height: 40),
            ElevatedButton(
              onPressed: () {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Signed In Successfully')),
                );
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.green,
                padding:
                    const EdgeInsets.symmetric(vertical: 14, horizontal: 40),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(30),
                ),
              ),
              child:
                  const Text('Sign In', style: TextStyle(color: Colors.white)),
            ),
          ],
        ),
      ),
    );
  }
}
