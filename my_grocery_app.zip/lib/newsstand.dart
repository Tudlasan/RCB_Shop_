import 'package:flutter/material.dart';

class Newsstand extends StatelessWidget {
  const Newsstand({super.key});

  @override
  Widget build(BuildContext context) {
    // Get navigation arguments
    final args =
        ModalRoute.of(context)?.settings.arguments as Map<String, dynamic>?;

    // Handle both List<String> and List<Map<String, String>>
    final dynamic newsArg = args?['news'];
    final List<Map<String, String>> newsList = [];

    if (newsArg != null) {
      if (newsArg is List<Map<String, String>>) {
        newsList.addAll(newsArg);
      } else if (newsArg is List<String>) {
        newsList.addAll(
          newsArg.map((title) => {
                'title': title,
                'description': 'No description available.',
                'image':
                    'https://cdn-icons-png.flaticon.com/512/565/565547.png',
              }),
        );
      }
    } else {
      newsList.add({
        'title': 'No news available',
        'description': 'Please check back later for updates.',
        'image': 'https://cdn-icons-png.flaticon.com/512/565/565547.png',
      });
    }

    return Scaffold(
      appBar: AppBar(
        title: const Text('Newsstand'),
        backgroundColor: Colors.white,
        foregroundColor: Colors.black,
        elevation: 1,
      ),
      body: ListView.builder(
        itemCount: newsList.length,
        itemBuilder: (context, index) {
          final news = newsList[index];
          return Card(
            margin: const EdgeInsets.symmetric(horizontal: 15, vertical: 8),
            elevation: 3,
            child: ListTile(
              leading: Image.network(
                news['image'] ?? '',
                width: 80,
                height: 80,
                fit: BoxFit.cover,
                errorBuilder: (context, error, stackTrace) =>
                    const Icon(Icons.image_not_supported),
              ),
              title: Text(
                news['title'] ?? '',
                style:
                    const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
              ),
              subtitle: Text(news['description'] ?? ''),
            ),
          );
        },
      ),
    );
  }
}
